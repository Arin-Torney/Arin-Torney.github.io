micro-css  
===
Readme by Arin Torney  
## Info  
micro.css is a CSS framework which is made for commonly used style by Ishan Kuber. This framework is iseful for education purposes and coding beginners. So go and enjoy this wonderful framework!!!
## Import the Framework  
You can either download it from [Ishan Kuber's website](https://ishankuber.github.io/Micro-CSS/css/micro.css) or use this in the `head` of your HTML.  
```HTML
<link rel="stylesheet" type="text/css" href="https://arin-torney.github.io/imkmicrocss/micro.min.css">
```  
## Cheat Sheet  
Syntax:
_extension_-_color_
_extension-color-hover_  
This is a list of extensions.  
```
text - Text Color
bg - Background
border - Border
outline - Outline
```  
This is a list of colors.  
```
black
white
blue
green
yellow
orange
```  
These are some examples.  
```
text-orange
bg-black
outline-yellow-hover
border-green
```  
This is how you put it in HTML.  
```HTML
<p class="text-orange-hover bg-blue border-yellow outline-green-hover">Hello World</p>
```
